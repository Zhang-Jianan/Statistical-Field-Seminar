
xelatex main.tex
bibtex main
makeindex main
xelatex main.tex
xelatex main.tex
